#!/usr/bin/env python3
"""OMDC platform server. Pure Python 3, no external packages."""
import os, json, sqlite3, hmac, hashlib, secrets, time, base64, re
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
import threading, glob

HERE = os.path.dirname(os.path.abspath(__file__))
DBP = os.environ.get("DB_PATH", os.path.join(HERE, "omdc.db"))
PORT = int(os.environ.get("PORT", "8000"))
TOKEN_TTL = 8 * 3600

# (key, label, type, required)  type: text | number | date | [options] | ref:<kind>
SCHEMA = {
 "project": {"label": "المشاريع", "f": [("name","اسم المشروع","text",1),("client_id","العميل","ref:client",0),("status","الحالة",["تخطيط","قيد التنفيذ","متوقف","مكتمل"],1),("progress","الإنجاز %","number",0),("budget","الميزانية","number",0)]},
 "contract": {"label": "العقود", "f": [("title","عنوان العقد","text",1),("project_id","المشروع","ref:project",1),("direction","نوع العقد",["عميل","مقاول باطن","مورد"],1),("party","الطرف الثاني","text",1),("value","قيمة العقد","number",1),("status","الحالة",["ساري","منتهي","ملغي"],1)]},
 "invoice": {"label": "المستخلصات", "f": [("number","رقم المستخلص","text",1),("project_id","المشروع","ref:project",1),("contract_id","العقد","ref:contract",0),("amount","قيمة المستخلص","number",1),("paid","المبلغ المحصّل","number",0),("status","الحالة",["مصدر","مدفوع جزئيًا","مدفوع"],1),("date","التاريخ","date",0)]},
 "expense": {"label": "المصروفات", "f": [("title","البيان","text",1),("project_id","المشروع","ref:project",1),("category","التصنيف",["مواد","عمالة","معدات","نقل","رواتب","أخرى"],1),("amount","المبلغ","number",1),("date","التاريخ","date",0)]},
 "client": {"label": "العملاء", "f": [("name","الاسم","text",1),("phone","الجوال","text",0),("email","البريد","text",0)]},
 "supplier": {"label": "الموردون", "f": [("name","الاسم","text",1),("category","التخصص","text",0),("phone","الجوال","text",0)]},
 "subcontractor": {"label": "مقاولو الباطن", "f": [("name","الاسم","text",1),("trade","التخصص","text",0),("phone","الجوال","text",0)]},
 "property": {"label": "العقارات", "f": [("name","اسم العقار","text",1),("type","النوع",["سكني","تجاري","صناعي"],1),("city","المدينة","text",0),("units","عدد الوحدات","number",1),("occupied","المؤجر منها","number",0)]},
 "ticket": {"label": "الصيانة", "f": [("title","وصف العطل","text",1),("property_id","العقار","ref:property",0),("priority","الأولوية",["عادي","عاجل"],1),("status","الحالة",["جديد","قيد التنفيذ","مكتمل"],1)]},
 "tenant": {"label": "المستأجرون", "f": [("name","الاسم","text",1),("phone","الجوال","text",0),("id_no","رقم الهوية / السجل","text",0)]},
 "lease": {"label": "عقود الإيجار", "f": [("tenant_id","المستأجر","ref:tenant",1),("property_id","العقار","ref:property",1),("unit","الوحدة","text",1),("rent","الإيجار السنوي","number",1),("start","بداية العقد","date",1),("end","نهاية العقد","date",1),("status","الحالة",["ساري","منتهي","ملغي"],1)]},
 "rent": {"label": "دفعات الإيجار", "f": [("lease_id","عقد الإيجار","ref:lease",1),("amount","المبلغ المستحق","number",1),("paid","المدفوع","number",0),("due","تاريخ الاستحقاق","date",1),("status","الحالة",["مستحق","مدفوع جزئيًا","مدفوع"],1)]},
 "quote": {"label": "نموذج عرض سعر", "f": [("number","رقم العرض","text",1),("client_id","العميل","ref:client",1),("project_id","المشروع","ref:project",0),("date","تاريخ العرض","date",1),("valid_until","صالح حتى","date",0),("items","البنود","lines",1),("discount","الخصم %","number",0),("vat","ضريبة القيمة المضافة %","number",0),("total","الإجمالي بعد الضريبة (تلقائي)","computed",0),("status","الحالة",["مسودة","مرسل","معتمد","مرفوض"],1),("notes","ملاحظات وشروط","area",0)]},
 "rental_form": {"label": "نموذج تأجير", "f": [("tenant_id","المستأجر","ref:tenant",1),("property_id","العقار","ref:property",1),("unit","الوحدة","text",1),("start","بداية العقد","date",1),("end","نهاية العقد","date",1),("annual_rent","الإيجار السنوي","number",1),("deposit","مبلغ التأمين","number",0),("plan","نظام الدفع",["سنوي","نصف سنوي","ربع سنوي","شهري"],1),("utilities","الخدمات المشمولة","text",0),("status","الحالة",["مسودة","معتمد","موقّع"],1),("notes","شروط إضافية","area",0)]},
 "pm_form": {"label": "نموذج إدارة أملاك", "f": [("property_id","العقار","ref:property",1),("owner_name","اسم المالك","text",1),("owner_phone","جوال المالك","text",0),("fee_pct","نسبة الإدارة %","number",1),("start","بداية التفويض","date",1),("end","نهاية التفويض","date",0),("scope","نطاق الإدارة","area",1),("status","الحالة",["مسودة","معتمد","موقّع"],1)]},
 "maint_form": {"label": "نموذج صيانة", "f": [("property_id","العقار","ref:property",1),("unit","الوحدة / الموقع","text",0),("category","نوع الصيانة",["كهرباء","سباكة","تكييف","مصاعد","نظافة","أخرى"],1),("description","وصف العمل","area",1),("priority","الأولوية",["عادي","عاجل"],1),("requested_by","مقدّم الطلب","text",0),("assigned_to","المنفّذ","text",0),("est_cost","التكلفة التقديرية","number",0),("date","التاريخ","date",1),("status","الحالة",["جديد","قيد التنفيذ","مكتمل"],1)]},
 "ops_form": {"label": "نموذج تشغيل", "f": [("property_id","العقار","ref:property",0),("kind","نوع التقرير",["فحص يومي","فحص أسبوعي","تسليم وردية","حادثة"],1),("date","التاريخ","date",1),("inspector","المسؤول","text",1),("findings","الملاحظات","area",1),("actions","الإجراءات المتخذة","area",0),("status","الحالة",["مفتوح","مغلق"],1)]},
}
ROLES = {"owner": "مالك", "manager": "مدير", "accountant": "محاسب", "engineer": "مهندس", "viewer": "مشاهد"}
FIN = {"contract": "", "invoice": "", "expense": "", "tenant": "", "lease": "", "rent": "", "quote": "", "rental_form": "", "pm_form": ""}
RP = {"manager": {"*": "rwd"},
      "accountant": {"*": "r", "contract": "rw", "invoice": "rw", "expense": "rw", "rent": "rw", "quote": "rw"},
      "engineer": {"*": "r", **FIN, "project": "rw", "ticket": "rwd", "maint_form": "rwd", "ops_form": "rwd"},
      "viewer": {"*": "r", **FIN}}
REPORT_ROLES = {"owner", "manager", "accountant"}
AUDIT_ROLES = {"owner", "manager"}
ALLOWED = {"pdf", "png", "jpg", "jpeg", "docx", "xlsx", "txt", "dwg"}
ACTIONS = {"create": "إضافة", "update": "تعديل", "delete": "حذف", "login": "دخول", "login_fail": "محاولة دخول فاشلة", "backup": "نسخ احتياطي", "restore": "استعادة", "setup": "إنشاء المالك"}

class Err(Exception):
    def __init__(s, msg, code=400): s.msg, s.code = msg, code

def db():
    c = sqlite3.connect(DBP, timeout=15); c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL"); return c

def init():
    c = db()
    c.executescript("""
    create table if not exists users(id integer primary key autoincrement, username text unique, name text, salt text, hash text, role text, active integer default 1, created_at real);
    create table if not exists records(id integer primary key autoincrement, kind text, data text, created_by text, created_at real, updated_at real);
    create index if not exists rk on records(kind);
    create table if not exists audit(id integer primary key autoincrement, ts real, user text, action text, kind text, rec_id integer, detail text);
    create table if not exists meta(k text primary key, v text);
    create table if not exists files(id integer primary key autoincrement, kind text, rec_id integer, name text, size integer, data blob, uname text, ts real);
    create index if not exists fk on files(kind,rec_id);""")
    c.commit(); c.close()

def secret():
    s = os.environ.get("SECRET_KEY")
    if s: return s.encode()
    c = db(); r = c.execute("select v from meta where k='secret'").fetchone()
    if not r:
        c.execute("insert into meta values('secret',?)", (secrets.token_hex(32),)); c.commit()
        r = c.execute("select v from meta where k='secret'").fetchone()
    c.close(); return r["v"].encode()

def hpw(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200000).hex()
def make_token(uid):
    b = base64.urlsafe_b64encode(json.dumps({"i": uid, "e": time.time() + TOKEN_TTL}).encode()).decode()
    return b + "." + hmac.new(SECRET, b.encode(), hashlib.sha256).hexdigest()
def read_token(t):
    try:
        b, sig = t.split(".")
        if not hmac.compare_digest(sig, hmac.new(SECRET, b.encode(), hashlib.sha256).hexdigest()): return None
        p = json.loads(base64.urlsafe_b64decode(b))
        return p["i"] if p["e"] > time.time() else None
    except Exception: return None

def perm(role, kind, op):
    if role == "owner": return True
    p = RP.get(role, {}); return op in p.get(kind, p.get("*", ""))
def perms_of(role): return {k: "".join(o for o in "rwd" if perm(role, k, o)) for k in SCHEMA}

def audit(c, user, action, kind="", rid=None, detail=""):
    c.execute("insert into audit(ts,user,action,kind,rec_id,detail) values(?,?,?,?,?,?)", (time.time(), user, action, kind, rid, detail[:600]))

def lab(kind, k): return next((f[1] for f in SCHEMA[kind]["f"] if f[0] == k), k)
def brief(kind, d): return " | ".join(f"{lab(kind,k)}: {v}" for k, v in d.items() if v not in ("", None))[:400]
def diff(kind, o, n): return " | ".join(f"{lab(kind,k)}: {o.get(k)} ← {n.get(k)}" for k in n if o.get(k) != n.get(k)) or "بدون تغيير"

def clean(kind, body, c):
    out = {}
    for k, label, t, req in SCHEMA[kind]["f"]:
        if t == "computed": continue
        v = body.get(k)
        if v in (None, ""):
            if req: raise Err("الحقل مطلوب: " + label)
            out[k] = None if (t == "number" or str(t).startswith("ref:")) else ""; continue
        if t == "number":
            try: v = float(v)
            except Exception: raise Err("قيمة غير صحيحة: " + label)
            if v < 0 or v > 1e13: raise Err("قيمة غير صحيحة: " + label)
            v = int(v) if v == int(v) else round(v, 2)
        elif t == "date":
            v = str(v).strip()
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v): raise Err("تاريخ غير صحيح: " + label)
        elif isinstance(t, list):
            if v not in t: raise Err("اختيار غير صحيح: " + label)
        elif t.startswith("ref:"):
            try: v = int(v)
            except Exception: raise Err("اختيار غير صحيح: " + label)
            if not c.execute("select 1 from records where id=? and kind=?", (v, t[4:])).fetchone(): raise Err("السجل المرتبط غير موجود: " + label)
        elif t == "area": v = str(v).strip()[:1500]
        elif t == "lines": v = str(v).strip()[:3000]
        else: v = str(v).strip()[:200]
        out[k] = v
    if kind == "project" and (out["progress"] or 0) > 100: raise Err("الإنجاز لا يزيد عن 100")
    if kind == "invoice" and (out["paid"] or 0) > out["amount"]: raise Err("المحصّل أكبر من قيمة المستخلص")
    if kind == "property" and (out["occupied"] or 0) > out["units"]: raise Err("المؤجر أكبر من عدد الوحدات")
    if kind == "quote":
        sub = 0
        for i, ln in enumerate([x for x in out["items"].split("\n") if x.strip()], 1):
            p = [x.strip() for x in ln.split("|")]
            try:
                q, pr = float(p[1]), float(p[2]); assert q >= 0 and pr >= 0
            except Exception: raise Err(f"سطر البنود رقم {i} غير صحيح. الصيغة: الوصف | الكمية | السعر")
            sub += q * pr
        if (out["discount"] or 0) > 100 or (out["vat"] or 0) > 100: raise Err("النسبة لا تزيد عن 100")
        out["total"] = round(sub * (1 - (out["discount"] or 0) / 100) * (1 + (out["vat"] or 0) / 100), 2)
        if out["valid_until"] and out["valid_until"] < out["date"]: raise Err("تاريخ الصلاحية قبل تاريخ العرض")
    if kind in ("rental_form", "pm_form") and out["end"] and out["end"] < out["start"]: raise Err("النهاية قبل البداية")
    if kind == "pm_form" and (out["fee_pct"] or 0) > 100: raise Err("النسبة لا تزيد عن 100")
    if kind == "rent" and (out["paid"] or 0) > out["amount"]: raise Err("المدفوع أكبر من المبلغ المستحق")
    if kind == "lease" and out["end"] < out["start"]: raise Err("نهاية العقد قبل بدايته")
    return out

def item(r):
    d = json.loads(r["data"]); d.update(id=r["id"], created_at=r["created_at"], updated_at=r["updated_at"], created_by=r["created_by"]); return d

def report(c):
    R = {k: [json.loads(r["data"]) | {"id": r["id"]} for r in c.execute("select * from records where kind=?", (k,))] for k in SCHEMA}
    s = lambda l, k: sum((x.get(k) or 0) for x in l)
    rows = []
    for p in R["project"]:
        pid = p["id"]; ct = [x for x in R["contract"] if x["project_id"] == pid and x["status"] != "ملغي"]
        inv = [x for x in R["invoice"] if x["project_id"] == pid]; ex = [x for x in R["expense"] if x["project_id"] == pid]
        rev = s([x for x in ct if x["direction"] == "عميل"], "value"); cost = s([x for x in ct if x["direction"] != "عميل"], "value")
        i, col, e = s(inv, "amount"), s(inv, "paid"), s(ex, "amount")
        rows.append({"id": pid, "name": p["name"], "status": p["status"], "progress": p.get("progress") or 0, "budget": p.get("budget") or 0, "revenue_contracts": rev, "cost_commitments": cost, "invoiced": i, "collected": col, "outstanding": i - col, "expenses": e, "net": col - e})
    cat = {}
    for x in R["expense"]: cat[x["category"]] = cat.get(x["category"], 0) + (x.get("amount") or 0)
    units, occ = s(R["property"], "units"), s(R["property"], "occupied")
    today = time.strftime("%Y-%m-%d"); rn = R["rent"]
    rent = {"due": s(rn, "amount"), "collected": s(rn, "paid"), "overdue": sum(x["amount"] - (x.get("paid") or 0) for x in rn if x["due"] < today and x["status"] != "مدفوع")}
    rent["outstanding"] = rent["due"] - rent["collected"]
    T = {k: sum(r[k] for r in rows) for k in ("revenue_contracts", "cost_commitments", "invoiced", "collected", "outstanding", "expenses", "net")}
    return {"totals": T, "projects": rows, "expense_by_category": cat, "active_projects": sum(1 for p in R["project"] if p["status"] == "قيد التنفيذ"),
            "units": units, "occupied": occ, "rent": rent, "active_leases": sum(1 for x in R["lease"] if x["status"] == "ساري"), "open_tickets": sum(1 for t in R["ticket"] if t["status"] != "مكتمل"),
            "counts": {k: len(R[k]) for k in ("client", "supplier", "subcontractor", "project")}}

FAILS = {}
def check_lock(key):
    n, until = FAILS.get(key, (0, 0))
    if n >= 5 and until > time.time(): raise Err("تم إيقاف المحاولات مؤقتًا، حاول بعد 5 دقائق", 429)
def fail(key):
    n, _ = FAILS.get(key, (0, 0)); FAILS[key] = (n + 1, time.time() + 300)

def user_row(c, u): return {k: u[k] for k in ("id", "username", "name", "role", "active", "created_at")}

def api(h, m, parts, q, body, c, u):
    a = parts[0] if parts else ""
    if a == "status" and m == "GET": return {"needs_setup": c.execute("select count(*) n from users").fetchone()["n"] == 0}
    if a == "setup" and m == "POST":
        if c.execute("select count(*) n from users").fetchone()["n"]: raise Err("تم الإعداد مسبقًا", 403)
        un, pw = str(body.get("username", "")).strip().lower(), str(body.get("password", ""))
        if not re.fullmatch(r"[a-z0-9._]{3,30}", un): raise Err("اسم المستخدم: حروف إنجليزية وأرقام، من 3 إلى 30")
        if len(pw) < 8: raise Err("كلمة المرور 8 أحرف على الأقل")
        salt = secrets.token_hex(16)
        cur = c.execute("insert into users(username,name,salt,hash,role,active,created_at) values(?,?,?,?,?,1,?)", (un, str(body.get("name", "المالك"))[:60] or "المالك", salt, hpw(pw, salt), "owner", time.time()))
        audit(c, un, "setup", "user", cur.lastrowid, "إنشاء حساب المالك"); return {"token": make_token(cur.lastrowid)}
    if a == "login" and m == "POST":
        un, pw = str(body.get("username", "")).strip().lower(), str(body.get("password", ""))
        key = un + "|" + h.client_address[0]; check_lock(key)
        r = c.execute("select * from users where username=?", (un,)).fetchone()
        if not r or not r["active"] or not hmac.compare_digest(hpw(pw, r["salt"]) if r else "", r["hash"] if r else "x"):
            fail(key); audit(c, un[:30], "login_fail", detail="بيانات دخول غير صحيحة"); c.commit(); raise Err("اسم المستخدم أو كلمة المرور غير صحيحة", 401)
        FAILS.pop(key, None); audit(c, un, "login", detail="تسجيل دخول"); return {"token": make_token(r["id"])}
    if not u: raise Err("يلزم تسجيل الدخول", 401)
    role, who = u["role"], u["username"]
    if a == "me" and len(parts) > 1 and parts[1] == "password" and m == "POST":
        if not hmac.compare_digest(hpw(str(body.get("old", "")), u["salt"]), u["hash"]): raise Err("كلمة المرور الحالية غير صحيحة")
        nw = str(body.get("new", ""))
        if len(nw) < 8: raise Err("كلمة المرور 8 أحرف على الأقل")
        salt = secrets.token_hex(16); c.execute("update users set salt=?,hash=? where id=?", (salt, hpw(nw, salt), u["id"]))
        audit(c, who, "update", "user", u["id"], "تغيير كلمة المرور الخاصة"); return {"ok": True}
    if a == "me":
        return {"user": user_row(c, u), "roles": ROLES, "perms": perms_of(role), "can_report": role in REPORT_ROLES, "can_audit": role in AUDIT_ROLES, "owner": role == "owner",
                "schema": {k: {"label": v["label"], "f": v["f"]} for k, v in SCHEMA.items()}}
    if a == "report" and m == "GET":
        if role not in REPORT_ROLES: raise Err("غير مصرح", 403)
        return report(c)
    if a == "audit" and m == "GET":
        if role not in AUDIT_ROLES: raise Err("غير مصرح", 403)
        lim = min(int(q.get("limit", ["300"])[0]), 2000)
        return [dict(r) for r in c.execute("select * from audit order by id desc limit ?", (lim,))]
    if a == "backup" and m == "GET":
        if role != "owner": raise Err("للمالك فقط", 403)
        audit(c, who, "backup", detail="تنزيل نسخة احتياطية")
        return {"app": "omdc", "version": 1, "at": time.time(), "users": [dict(r) for r in c.execute("select * from users")], "records": [dict(r) for r in c.execute("select * from records")], "audit": [dict(r) for r in c.execute("select * from audit")], "files": [{**dict(r), "data": base64.b64encode(r["data"]).decode()} for r in c.execute("select * from files")]}
    if a == "restore" and m == "POST":
        if role != "owner": raise Err("للمالك فقط", 403)
        if body.get("app") != "omdc" or not all(isinstance(body.get(k), list) for k in ("users", "records", "audit")): raise Err("ملف النسخة الاحتياطية غير صالح")
        U, Rc, A = body["users"], body["records"], body["audit"]
        try:
            for x in U:
                if x["role"] not in ROLES or not x["username"]: raise ValueError
            for x in Rc:
                if x["kind"] not in SCHEMA: raise ValueError
                json.loads(x["data"])
            if not any(x["role"] == "owner" and x["active"] for x in U): raise ValueError
        except Exception: raise Err("محتوى النسخة الاحتياطية غير صالح")
        snap = sqlite3.connect(DBP + ".pre-restore"); c.backup(snap); snap.close()
        c.execute("delete from users"); c.execute("delete from records"); c.execute("delete from audit"); c.execute("delete from files")
        for x in (body.get("files") or []): c.execute("insert into files(id,kind,rec_id,name,size,data,uname,ts) values(?,?,?,?,?,?,?,?)", [x["id"], x["kind"], x["rec_id"], x["name"], x["size"], base64.b64decode(x["data"]), x.get("uname"), x.get("ts")])
        for x in U: c.execute("insert into users(id,username,name,salt,hash,role,active,created_at) values(?,?,?,?,?,?,?,?)", [x.get(k) for k in ("id", "username", "name", "salt", "hash", "role", "active", "created_at")])
        for x in Rc: c.execute("insert into records(id,kind,data,created_by,created_at,updated_at) values(?,?,?,?,?,?)", [x.get(k) for k in ("id", "kind", "data", "created_by", "created_at", "updated_at")])
        for x in A: c.execute("insert into audit(id,ts,user,action,kind,rec_id,detail) values(?,?,?,?,?,?,?)", [x.get(k) for k in ("id", "ts", "user", "action", "kind", "rec_id", "detail")])
        audit(c, who, "restore", detail=f"استعادة: {len(U)} مستخدم، {len(Rc)} سجل"); return {"ok": True}
    if a == "users":
        if role != "owner": raise Err("للمالك فقط", 403)
        if m == "GET": return [user_row(c, r) for r in c.execute("select * from users order by id")]
        if m == "POST":
            un, pw, rl = str(body.get("username", "")).strip().lower(), str(body.get("password", "")), body.get("role")
            if not re.fullmatch(r"[a-z0-9._]{3,30}", un): raise Err("اسم المستخدم: حروف إنجليزية وأرقام، من 3 إلى 30")
            if len(pw) < 8: raise Err("كلمة المرور 8 أحرف على الأقل")
            if rl not in ROLES: raise Err("دور غير صحيح")
            if c.execute("select 1 from users where username=?", (un,)).fetchone(): raise Err("اسم المستخدم مستخدم مسبقًا")
            salt = secrets.token_hex(16)
            cur = c.execute("insert into users(username,name,salt,hash,role,active,created_at) values(?,?,?,?,?,1,?)", (un, str(body.get("name", un))[:60] or un, salt, hpw(pw, salt), rl, time.time()))
            audit(c, who, "create", "user", cur.lastrowid, f"مستخدم: {un} ({ROLES[rl]})"); return {"id": cur.lastrowid}
        if len(parts) > 1:
            uid = int(parts[1]); t = c.execute("select * from users where id=?", (uid,)).fetchone()
            if not t: raise Err("غير موجود", 404)
            others = c.execute("select count(*) n from users where role='owner' and active=1 and id<>?", (uid,)).fetchone()["n"]
            if m == "DELETE":
                if uid == u["id"] or (t["role"] == "owner" and not others): raise Err("لا يمكن حذف هذا الحساب")
                c.execute("delete from users where id=?", (uid,)); audit(c, who, "delete", "user", uid, "مستخدم: " + t["username"]); return {"ok": True}
            if m == "PUT":
                rl = body.get("role", t["role"]); act = 1 if body.get("active", bool(t["active"])) else 0
                if rl not in ROLES: raise Err("دور غير صحيح")
                if (uid == u["id"] and (rl != t["role"] or not act)) or (t["role"] == "owner" and (rl != "owner" or not act) and not others): raise Err("لا يمكن تعديل دور هذا الحساب أو تعطيله")
                salt, hh, note = t["salt"], t["hash"], []
                if body.get("password"):
                    if len(str(body["password"])) < 8: raise Err("كلمة المرور 8 أحرف على الأقل")
                    salt = secrets.token_hex(16); hh = hpw(str(body["password"]), salt); note.append("تغيير كلمة المرور")
                if rl != t["role"]: note.append(f"الدور: {ROLES[t['role']]} ← {ROLES[rl]}")
                if act != t["active"]: note.append("تفعيل" if act else "تعطيل")
                c.execute("update users set name=?,role=?,active=?,salt=?,hash=? where id=?", (str(body.get("name", t["name"]))[:60], rl, act, salt, hh, uid))
                audit(c, who, "update", "user", uid, f"{t['username']}: " + (" | ".join(note) or "تعديل الاسم")); return {"ok": True}
    if a == "files":
        if m == "GET" and len(parts) == 1:
            kind = q.get("kind", [""])[0]; rid = int(q.get("rec_id", ["0"])[0])
            if kind not in SCHEMA or not perm(role, kind, "r"): raise Err("غير مصرح", 403)
            return [dict(r) for r in c.execute("select id,name,size,uname,ts from files where kind=? and rec_id=? order by id desc", (kind, rid))]
        if m == "POST" and len(parts) == 1:
            kind = body.get("kind")
            if kind not in SCHEMA or not perm(role, kind, "w"): raise Err("غير مصرح", 403)
            rid = int(body.get("rec_id", 0))
            if not c.execute("select 1 from records where id=? and kind=?", (rid, kind)).fetchone(): raise Err("السجل غير موجود", 404)
            name = re.sub(r"[^\w.\- ]", "_", str(body.get("name", "file")))[:100]
            if name.rsplit(".", 1)[-1].lower() not in ALLOWED: raise Err("نوع الملف غير مسموح")
            try: data = base64.b64decode(body.get("data", ""), validate=True)
            except Exception: raise Err("ملف غير صالح")
            if not data or len(data) > 5_000_000: raise Err("حجم الملف غير صالح (الحد 5 ميغابايت)")
            cur = c.execute("insert into files(kind,rec_id,name,size,data,uname,ts) values(?,?,?,?,?,?,?)", (kind, rid, name, len(data), data, who, time.time()))
            audit(c, who, "create", "file", cur.lastrowid, f"مرفق: {name} على {SCHEMA[kind]['label']} #{rid}"); return {"id": cur.lastrowid}
        if len(parts) == 2:
            r = c.execute("select * from files where id=?", (int(parts[1]),)).fetchone()
            if not r: raise Err("غير موجود", 404)
            if m == "GET":
                if not perm(role, r["kind"], "r"): raise Err("غير مصرح", 403)
                return ("raw", bytes(r["data"]), r["name"])
            if m == "DELETE":
                if not perm(role, r["kind"], "d"): raise Err("غير مصرح", 403)
                c.execute("delete from files where id=?", (r["id"],)); audit(c, who, "delete", "file", r["id"], "مرفق: " + r["name"]); return {"ok": True}
    if a in SCHEMA:
        kind = a
        if m == "GET" and len(parts) == 1:
            if not perm(role, kind, "r"): raise Err("غير مصرح", 403)
            return [item(r) for r in c.execute("select * from records where kind=? order by id desc", (kind,))]
        if m == "POST" and len(parts) == 1:
            if not perm(role, kind, "w"): raise Err("غير مصرح", 403)
            d = clean(kind, body, c); now = time.time()
            cur = c.execute("insert into records(kind,data,created_by,created_at,updated_at) values(?,?,?,?,?)", (kind, json.dumps(d, ensure_ascii=False), who, now, now))
            audit(c, who, "create", kind, cur.lastrowid, brief(kind, d)); return {"id": cur.lastrowid}
        if len(parts) == 2:
            rid = int(parts[1]); r = c.execute("select * from records where id=? and kind=?", (rid, kind)).fetchone()
            if not r: raise Err("غير موجود", 404)
            old = json.loads(r["data"])
            if m == "PUT":
                if not perm(role, kind, "w"): raise Err("غير مصرح", 403)
                d = clean(kind, {**old, **body}, c)
                c.execute("update records set data=?,updated_at=? where id=?", (json.dumps(d, ensure_ascii=False), time.time(), rid))
                audit(c, who, "update", kind, rid, diff(kind, old, d)); return {"ok": True}
            if m == "DELETE":
                if not perm(role, kind, "d"): raise Err("غير مصرح", 403)
                c.execute("delete from records where id=?", (rid,)); c.execute("delete from files where kind=? and rec_id=?", (kind, rid)); audit(c, who, "delete", kind, rid, brief(kind, old)); return {"ok": True}
    raise Err("غير موجود", 404)

CT = {".html": "text/html; charset=utf-8", ".jpg": "image/jpeg"}
class H(BaseHTTPRequestHandler):
    server_version = "OMDC"
    def log_message(self, *a): pass
    def send_(self, code, body, ct="application/json; charset=utf-8", extra=None):
        if not isinstance(body, bytes): body = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        for k, v in {"Content-Type": ct, "Content-Length": str(len(body)), "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Cache-Control": "no-store",
                     "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:"}.items(): self.send_header(k, v)
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)
    def go(self, m):
        p = urlparse(self.path)
        if m == "GET" and p.path in ("/", "/index.html", "/logo.jpg"):
            f = "logo.jpg" if p.path == "/logo.jpg" else "index.html"
            return self.send_(200, open(os.path.join(HERE, f), "rb").read(), CT[os.path.splitext(f)[1]])
        if not p.path.startswith("/api/"): return self.send_(404, {"error": "غير موجود"})
        c = db()
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n > (80e6 if p.path == "/api/restore" else 8e6 if p.path == "/api/files" else 1e6): raise Err("الحجم كبير", 413)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            if not isinstance(body, dict): raise Err("طلب غير صحيح")
            tok = (self.headers.get("Authorization") or "")[7:]; uid = read_token(tok) if tok else None
            u = c.execute("select * from users where id=? and active=1", (uid,)).fetchone() if uid else None
            res = api(self, m, [x for x in p.path[5:].split("/") if x], parse_qs(p.query), body, c, u); c.commit()
            if isinstance(res, tuple): return self.send_(200, res[1], "application/octet-stream", {"Content-Disposition": "attachment; filename*=UTF-8''" + quote(res[2])})
            self.send_(200, res)
        except Err as e:
            c.commit(); self.send_(e.code, {"error": e.msg})
        except (ValueError, KeyError, TypeError):
            c.rollback(); self.send_(400, {"error": "طلب غير صحيح"})
        except Exception:
            c.rollback(); self.send_(500, {"error": "خطأ في الخادم"})
        finally: c.close()
    def do_GET(self): self.go("GET")
    def do_POST(self): self.go("POST")
    def do_PUT(self): self.go("PUT")
    def do_DELETE(self): self.go("DELETE")

def auto_backup():
    d = os.environ.get("BACKUP_DIR", os.path.join(os.path.dirname(os.path.abspath(DBP)), "backups")); os.makedirs(d, exist_ok=True)
    while True:
        try:
            f = os.path.join(d, "omdc-" + time.strftime("%Y%m%d") + ".db")
            if not os.path.exists(f):
                s = db(); t = sqlite3.connect(f); s.backup(t); t.close(); s.close()
                for old in sorted(glob.glob(os.path.join(d, "omdc-*.db")))[:-14]: os.remove(old)
        except Exception: pass
        time.sleep(3600)

init(); SECRET = secret()
if __name__ == "__main__":
    print(f"OMDC running on port {PORT}, database: {DBP}")
    threading.Thread(target=auto_backup, daemon=True).start()
    ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
